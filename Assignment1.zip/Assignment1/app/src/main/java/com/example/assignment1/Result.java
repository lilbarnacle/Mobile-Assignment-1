package com.example.assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Result extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        //creating textview for total, which is the final calculation (monthly payment)
        TextView textview = (TextView) findViewById(R.id.total);

        Bundle extras = getIntent().getExtras();

        if(extras != null)
        {

            //creating variables for calculations
            Double principle = Double.parseDouble(extras.getString("principle"));

            Double interest = Double.parseDouble(extras.getString("interest"));

            Double term = Double.parseDouble(extras.getString("term"));

            interest = (interest / 100)/12;

            //formula for monthly payment
            double total = (principle * interest * (Math.pow((1 + interest),term)))/(Math.pow(1+interest, term) - 1);

            //formatting output to be 2 decimal places
            textview.setText("$" + String.format("%.2f",total));

        }
    }
}