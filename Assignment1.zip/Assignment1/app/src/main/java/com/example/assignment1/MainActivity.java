package com.example.assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void calculate(View v)
    {
        //EditText maps the variables we create here to the variables on the display
        EditText principle = findViewById(R.id.principleamount);
        EditText interest = findViewById(R.id.interestrate);
        EditText term = findViewById(R.id.mortgageterm);

        //creating a string from the input
        String principleamount = principle.getText().toString();
        String interestrate = interest.getText().toString();
        String mortgageterm = term.getText().toString();


        //Intent to connect mainactivity to result
        Intent i = new Intent ( MainActivity.this, Result.class);
        //adding extended data for the key principle, to the data principleamount
        i.putExtra("principle", principleamount);
        i.putExtra("interest", interestrate);
        i.putExtra("term", mortgageterm);

        //validation, ensuring that the fields are not empty
        if(principleamount == "")
            Toast.makeText(getApplicationContext(),"Please enter a value for principal amount",Toast.LENGTH_SHORT).show();

        if(interestrate == "")
            Toast.makeText(getApplicationContext(),"Please enter a value for interest rate",Toast.LENGTH_SHORT).show();

        if(mortgageterm == "")
            Toast.makeText(getApplicationContext(),"Please enter a value for mortgage term",Toast.LENGTH_SHORT).show();

        //if all of the fields are not empty, proceed to Result
        if(principleamount != "" && interestrate != "" && mortgageterm != "")
            startActivity(i);
    }
}